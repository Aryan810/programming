1: In /backend/mails/route.js -> in marking the mail as star we also need its it (like that for deleting), so we have to use /star/:id, this is also becouse they used resp.params in staring controller.

2: In /backend/mails/model.js -> the default 'status' should be 'unseen'

3: Route for markAsRead() is not given initially.

4: The router method for UPDATING THE 'starred' property should be a PATCH request. (not GET)

5: 'markAsRead()' function should also be exported.