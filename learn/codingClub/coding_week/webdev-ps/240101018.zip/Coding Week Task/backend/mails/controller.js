import { response } from "express";
import MailSchema from "./model.js";

export const createMail = async (req, res) => {
	const { sender, reciever, type, subject, body } = req.body;
	try {
		const mail = new MailSchema({
			sender,
			reciever,
			type,
			subject,
			body,
		});
		mail.save();
		res.status(201).json(mail);
	} catch (error) {
		res.status(500).json({ message: "Error creating mail", error });
	}
};

export const getMails = async (req, res) => {
	try {
		const mails = await MailSchema.find();
		res.status(200).json(mails);
	} catch (error) {
		res.status(500).json({ message: error.message });

	}
};

export const deleteMail = async (req, res) => {
	const { id } = req.params;
	try {
		const resp = await MailSchema.findByIdAndDelete(id);
		if (resp) {
			console.log("Deleted ", id);
			res.status(200).json(resp);
		} else {
			res.status(401).json({ message: "Error: no email with id: ", id });
		}
	} catch (error) {
		res.status(500).json({ message: "Error deleting mail", error });
	}
};

export const starMail = async (req, res) => {
	const { id } = req.params;
	console.log(id);
	try {
		const ele = await MailSchema.findById(id);
		// console.log(ele);
		ele['starred'] = !ele['starred'];
		await ele.save();
		// console.log(ele);
		res.status(200).json(ele);
		console.log("Starred ", id);
	} catch (error) {
		console.log(error);
		res.status(500).json({ message: "Error starring mail", error });
	}
};

export const markAsRead = async (req, res) => {
	const { id } = req.params;
	try {
		const ele = await MailSchema.findById(id);
		if (ele["status"] == "seen") {
			if (req.body = "mark-unseen") {
				ele["status"] = "unseen";
				await ele.save();
				console.log("Marked as unseen ", id);
			}
			else { res.status(200).json({ message: "Already seen, no need to patch again !" }) }
		} else {
			ele["status"] = "seen";
			await ele.save();
			console.log("Marked as seen ", id);
		}
		res.status(200).json(ele);
	} catch (error) {
		console.log(error);
		res.status(500).json({ message: "Error marking mail as read", error });
	}
};
