let inbox_cnt = 0;
let drafts_cnt = 0;
let spam_cnt = 0;
let currentMails;
let selected = new Set();
const email_box = document.querySelector(".email-box tbody");
const reload = document.querySelector(".reload")
const delete_btn = document.querySelector(".delete");
const ham_btn = document.querySelector(".ham-btn");
const i_cnt = document.querySelector(".inbox .box-num");
const s_cnt = document.querySelector(".spam .box-num");
const d_cnt = document.querySelector(".drafts .box-num");
const ham = document.querySelector(".left-box");
const head_range_text = document.querySelector(".head-range-text");
const compose_content = document.querySelector(".compose-content");
const main_section = document.querySelector(".main-section");
let cnts = {
    "primary": [0, main_section.querySelector(".primary-box .head-alert-num")],
    "social": [0, main_section.querySelector(".social-box .head-alert-num")],
    "promotions": [0, main_section.querySelector(".promotions-box .head-alert-num")],
    "updates": [0, main_section.querySelector(".updates-box .head-alert-num")],
}
let selected_section = "primary";

const starred_icon = `
     <svg class="round-border" width="22" height="22" viewBox="0 0 22 22" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M10.9999 15.8308L16.6649 19.2499L15.1616 12.8058L20.1666 8.46992L13.5758 7.91075L10.9999 1.83325L8.42409 7.91075L1.83325 8.46992L6.83825 12.8058L5.33492 19.2499L10.9999 15.8308Z"
                                    fill="#EFD494" />
                            </svg>
    `
const unstarred_icon = `
<svg class="round-border" width="22" height="22" viewBox="0 0 22 22" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M12.885 8.20337L13.0618 8.61938L13.512 8.65845L18.3303 9.06665L14.6702 12.2385L14.3284 12.5354L14.4309 12.9758L15.5305 17.6887L11.3879 15.1887L11.0002 14.9543L10.6125 15.1887L6.46899 17.6887L7.5686 12.9758L7.67114 12.5354L7.32935 12.2385L3.66821 9.06665L8.48755 8.65845L8.93774 8.61938L9.1145 8.20337L10.9993 3.75513L12.885 8.20337Z"
                                stroke="black" stroke-opacity="0.16" stroke-width="1.5" />
                        </svg>
`
const tick_icon = `
<!-- ticked state ! -->
                            <svg class="ticked round-border" width="22" height="22" viewBox="0 0 22 22" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_644_1966)">
                                    <path
                                        d="M17.4167 2.75H4.58333C3.56583 2.75 2.75 3.575 2.75 4.58333V17.4167C2.75 18.425 3.56583 19.25 4.58333 19.25H17.4167C18.4342 19.25 19.25 18.425 19.25 17.4167V4.58333C19.25 3.575 18.4342 2.75 17.4167 2.75ZM9.16667 15.5833L4.58333 11L5.87583 9.7075L9.16667 12.9892L16.1242 6.03167L17.4167 7.33333L9.16667 15.5833Z"
                                        fill="black" fill-opacity="0.54" />
                                </g>
                                <defs>
                                    <clipPath id="clip0_644_1966">
                                        <rect width="22" height="22" fill="white" />
                                    </clipPath>
                                </defs>
                            </svg>
`
const untick_icon = `
<!-- unticked state ! -->
                            <svg class="unticked round-border" width="22" height="22" viewBox="0 0 22 22" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_644_1937)">
                                    <path
                                        d="M17.6667 4.83333V17.6667H4.83333V4.83333H17.6667ZM17.6667 3H4.83333C3.825 3 3 3.825 3 4.83333V17.6667C3 18.675 3.825 19.5 4.83333 19.5H17.6667C18.675 19.5 19.5 18.675 19.5 17.6667V4.83333C19.5 3.825 18.675 3 17.6667 3Z"
                                        fill="black" fill-opacity="0.16" />
                                </g>
                                <defs>
                                    <clipPath id="clip0_644_1937">
                                        <rect width="22" height="22" fill="white" />
                                    </clipPath>
                                </defs>
                            </svg>
`

// function truncate(body, mx){
//     if (body.length > mx){body = body.slice(0, mx);}
//     return body + '...';
// }

function toShowDate(dateRaw) {
    // console.log(dateRaw)
    const date = new Date(dateRaw);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const months = ["January", "February", "March", "April", "May", "June", "July",
        "August", "September", "October", "November", "December"];
    const day = String(date.getDate()).padStart(2, '0');
    // console.log(date.getDate())
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const today = new Date();
    if (today.getFullYear() == year) {
        if ((today.getMonth() == date.getMonth()) && (today.getDate() == date.getDate())) {
            am = 'AM';
            h = date.getHours()
            if (h >= 12) {
                am = 'PM'
                h = h % 12;
            }
            if (h == 0){
                h = 12;
            }
            return `${h}:${minutes} ${am}`
        } else {
            return `${day}, ${months[date.getMonth()]}`
        }
    } else {
        return `${day}/${month}/${year}`;
    }

}

function makeEmailHTML(sender, starred, date, body, subject) {
    let star_icon = starred_icon;
    if (!starred){
        star_icon = unstarred_icon;
    }
    // let mx = 130;
    // let showing_body = body;
    // let if_to_show_body = `&nbsp;- &nbsp;<div class="email-body-glance">${showing_body}</div>`;
    // if (subject.length > mx){
    //     if_to_show_body = "";
    //     subject = truncate(subject, mx);
    // }else if (subject.length + body.length > mx){
    //     showing_body = truncate(showing_body, mx-subject.length);
    //     if_to_show_body = `&nbsp;- &nbsp;<div class="email-body-glance">${showing_body}</div>`
    // }
    template = `
                    <td class="select unticked" title="Select">
                        ${untick_icon}
                    </td>
                    <td class="star" title="Star">
                        ${star_icon}
                    </td>
                    <td class="email-author" title="${sender}">
                        ${sender}
                    </td>
                    <td class="email-glance" title="${subject + "\n" + body.slice(0, 100) + '...'}">
                        <span class="subject">${subject}</span><span class="space">&nbsp;-&nbsp;</span><span class="email-body">${body}</span>
                    </td>
                    <td class="email-date">
                        <div class="email-date-btns">
                            <button title="Delete">
                                <svg class="email-date-btn round-border deletesvg" width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M5.50004 17.4167C5.50004 18.425 6.32504 19.25 7.33337 19.25H14.6667C15.675 19.25 16.5 18.425 16.5 17.4167V6.41667H5.50004V17.4167ZM17.4167 3.66667H14.2084L13.2917 2.75H8.70837L7.79171 3.66667H4.58337V5.5H17.4167V3.66667Z" fill="black" fill-opacity="0.54"/>
                                </svg>
                            </button>
                            <button title="Mark as unseen">
                                <svg class="email-date-btn mark-as-unreadsvg round-border" width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M17.147 6.47368H14.807L9.65 3.78947L3.8 6.83158V15.4211C2.81 15.4211 2 14.6158 2 13.6316V6.62579C2 6.15158 2.288 5.65053 2.72 5.42684L9.65 2L16.436 5.42684C16.823 5.63263 17.093 6.05316 17.147 6.47368ZM18.2 7.36842H6.5C5.51 7.36842 4.7 8.17368 4.7 9.15789V17.2105C4.7 18.1947 5.51 19 6.5 19H18.2C19.19 19 20 18.1947 20 17.2105V9.15789C20 8.17368 19.19 7.36842 18.2 7.36842ZM18.2 10.6521L12.35 13.6316L6.5 10.6521V9.15789L12.35 12.1374L18.2 9.15789V10.6521Z" fill="black" fill-opacity="0.54"/>
                                </svg>  
                            </button>
                        </div>
                        <div class="email-date-text">
                            ${toShowDate(date)}
                        </div>
                    </td>
                 
    `
    return template;
}

function update_cnts(){
    if (inbox_cnt > 0){
        document.querySelector(".inbox").style.fontWeight = "700";
    }
    i_cnt.textContent = inbox_cnt;
    if (spam_cnt > 0){
        document.querySelector(".spam").style.fontWeight = "700";
    }else{
        document.querySelector(".spam").style.fontWeight = "400";
    }
    s_cnt.textContent = spam_cnt;
    if (drafts_cnt > 0){
        document.querySelector(".drafts").style.fontWeight = "700";
    }
    d_cnt.textContent = drafts_cnt;

    // changing section cnts
    cnts.primary[1].textContent = cnts.primary[0];
    cnts.social[1].textContent = cnts.social[0];
    cnts.promotions[1].textContent = cnts.promotions[0];
    cnts.updates[1].textContent = cnts.updates[0];
}

async function EventHandlerEmails(event){
    let lastDiv = event.target

    // finding last "SVG" element (if any)
    let j = 0;
    let lastSvg = lastDiv;
    while (j < 3 && (lastSvg && lastSvg.tagName.toLowerCase() != "svg")){
        lastSvg = lastSvg.parentElement;
        j += 1;
    }

    if (lastDiv.tagName != "TR"){
        while (lastDiv.tagName != "TD"){
            lastDiv = lastDiv.parentElement
        }
    }
    try{
    let email = lastDiv;
    let i = 0
    while (!email.classList.contains("email") && i < 10){
        email = email.parentElement;
        i += 1;
    }
    console.log("Email clicked: ", email);
    if (email){
        if (email.classList.contains("unseen")){
            try{
                const resp = await fetch(`http://localhost:8000/api/mail/read/${email.id}`, {method: "PATCH"})
                const jsonresp = await resp.json();
                if (resp.status == 200){
                    email.classList.remove("unseen");
                    email.classList.add("seen");
                    inbox_cnt -= 1;
                    cnts[selected_section][0] -= 1;
                    update_cnts();
                }else{
                    console.log("Error marking as read: ", resp.body());
                }
            }catch(error){
                console.log("Error marking read <", email.id, "> -> ", error);
            }
        }
    }
    // case 1 - checkbox is clicked
    if (lastDiv.className == "select ticked"){
        lastDiv.className = "select unticked";
        email.classList.remove("selected");
        selected.delete(email.id)
        if (selected.size == 0){
            delete_btn.classList.add("hide");
        }
        lastDiv.innerHTML = untick_icon;
    }else if (event.target.parentElement.className == "select unticked"){
        lastDiv.className = "select ticked";
        email.classList.add("selected");
        selected.add(email.id);
        if (delete_btn.classList.contains("hide")){
            delete_btn.classList.remove("hide");
        }
        lastDiv.innerHTML = tick_icon;
    }

    // star btn clicked
    if (lastDiv.className == "star"){
        try{
            const resp = await fetch(`http://localhost:8000/api/mail/star/${email.id}`, {method: "PATCH"})
            const jsonresp = await resp.json();
            if (resp.status === 200){
                if (!jsonresp['starred']){
                    lastDiv.innerHTML = unstarred_icon;
                }else{
                    lastDiv.innerHTML = starred_icon;
                }
            }else{
                throw resp.body;
            }
        }catch(error){
            console.log("Error marking star <", email.id, "> -> ", error);
        }
    }
   

    // case 3: delete (self) btn pressed
    if (lastSvg.classList.contains("deletesvg")){
        deleteOne(email.id);
    }else if (lastSvg.classList.contains("mark-as-unreadsvg")){
        if (email.classList.contains("seen")){
            try{
                const resp = await fetch(`http://localhost:8000/api/mail/read/${email.id}`, {method: "PATCH", 
                    body: "mark_unseen"
                });
                if (resp.status == 200){
                    email.classList.remove("seen");
                    email.classList.add("unseen");
                    inbox_cnt += 1;
                    cnts[selected_section][0] += 1;
                    update_cnts();
                }else{
                    console.log("Error marking as unread: ", resp.body());
                }
            }catch(error){
                console.log("Error marking unread <", email.id, "> -> ", error);
            }
        }
    }


    // this catches any uncaught error in requests or anything.
    }catch(error){
        // console.log(error);
    }
}

function addEmailsToDOM(mails, to_empty){
    if (to_empty){
        let child = email_box.lastElementChild;
        while (child){
            email_box.removeChild(child);
            child = email_box.lastElementChild;
        }
    }
    let mails_added_len = 0;
    for (let i=0;i<mails.length;i++){
        const mail = mails[i];
        if (mail.status == "unseen"){
            inbox_cnt += 1;
            cnts[mail.type][0] += 1;
        }

        if (mail.type != selected_section){
            continue;
        }
        mails_added_len += 1;
        let email = document.createElement("tr");
        email.innerHTML = makeEmailHTML(mail.sender, mail.starred, mail.createdAt, mail.body, mail.subject);
        email.id = mail._id;
        email.className = "email"
        if (mail.status === "seen"){
            email.classList.add("seen")
        }else{
            email.classList.add("unseen")
        }
        // seperator = document.createElement("div");
        // seperator.className = "seperator";
        email_box.insertBefore(email, email_box.firstChild);
        // email_box.appendChild(seperator);
    }
    update_cnts();
    return mails_added_len;
}

function addEvents(){
    email_box.addEventListener("click", EventHandlerEmails);
}
function updateHeadRangeText(len){
    if (len != 0){head_range_text.textContent = `1 - ${len}`;}else{
            head_range_text.textContent = '0';
    }
}

async function deleteOne(id){
    const resp = await fetch(`http://localhost:8000/api/mail/delete/${id}`, {method: "DELETE"});
    const jsonresp = await resp.json();
    if (resp.status == 200){
        email_box.removeChild(document.getElementById(id));
        updateHeadRangeText(Number(head_range_text.textContent.split(" - ")[1])-1); // here i am updating the total count of emails.
    }else{
        console.log("Error deleting <", id, "> : ", jsonresp);
    }
}

// this is for deleting all selected emails.
async function onDelClick(){
    // console.log(selected);
    for (const id of selected){
        deleteOne(id);
    }
    selected.clear();
    if (!delete_btn.classList.contains("hide")){
        delete_btn.classList.add("hide");
    }
}

async function colapseHam(){
    const colaseElements = document.querySelectorAll(".colapse");
    let newstyle = `
                    padding: 0px 5px 0px 5px;
                    margin: 0px 12px 0px 20px;
                    border-radius: 50%;
                    height: 40px;
                    
                `;
    let icon_style = `
                    justify-content: center;
                    border-radius: 50%;
    `;

    // console.log(ham.style)
    for (const ele of colaseElements){
        const parent = ele.parentElement;
        const icon = parent.querySelector(".box-icon");
        if (ele.classList.contains("hide")){
            ele.classList.remove("hide");
            if (parent){
                parent.style.width = "80%";
                if (parent.className != "compose-content"){
                    parent.style.cssText -= newstyle;
                }
                if (icon){icon.style.cssText -= icon_style;}
            }
        }else{
            ele.classList.add("hide");
            if (parent){
                parent.style.width = "40px";
                if (parent.className != "compose-content"){
                    parent.style.cssText += newstyle;
                }
                if (icon){icon.style.cssText += icon_style;}
            }
        }
        // console.log(parent.style);
    }
    if (ham.style.width == "90px"){
        ham.style.width = "calc(var(--ham-width) + 10px)";
        ham.style.minWidth = "calc(var(--ham-width) + 10px)";
        compose_content.style.width = "126px";
    }else{
        ham.style.width = "90px";
        ham.style.minWidth = "90px";
        compose_content.style.width = "72px";
    }
}

async function fetchMails() {
    reload.addEventListener('click', reloadMails)
    delete_btn.addEventListener('click', onDelClick)
    ham_btn.addEventListener('click', colapseHam)
    main_section.addEventListener('click', section_change);
    try {
        const response = await fetch("http://localhost:8000/api/mail/getAll");
        const mails = await response.json();
        currentMails = mails;
        console.log(mails)
        updateHeadRangeText(mails.length);
        addEmailsToDOM(mails, false);
        addEvents();
    } catch (error) {
        // mailContainer.innerHTML = `<p>Error fetching mails: ${error.message}</p>`;
        console.log(error);
    }
}

function min(a, b){
    if (a > b){
        return b;
    }else{
        return a;
    }
}

async function section_change(event) {
    t = event.target;
    let i = 0;
    while (i < 5 && !t.classList.contains("sbox")){
        t = t.parentElement;
        i += 1;
    }
    if (!t.classList.contains("sbox")){return;}else{
        if (t){
            // remove groove from last section.
            const ss = main_section.querySelector(`.${selected_section}-box`);
            ss.removeChild(ss.querySelector(".groove"));
            selected_section = t.classList[0].slice(0, -4);
            const groove = document.createElement('div');
            groove.className = "groove";
            t.appendChild(groove);
            reloadMails();
        }
    }
}

async function reloadMails() {    
    reload.style.transform = 'rotate(360deg)';
    if (!delete_btn.classList.contains("hide")){
        delete_btn.classList.add("hide");
    }
    inbox_cnt = 0;
    cnts.primary[0] = 0;
    cnts.social[0] = 0;
    cnts.promotions[0] = 0;
    cnts.updates[0] = 0;
    try {
        const response = await fetch("http://localhost:8000/api/mail/getAll");
        const mails = await response.json();
        currentMails = mails;
        console.log(mails)
        const mails_added_len = addEmailsToDOM(mails, true);
        updateHeadRangeText(mails_added_len);
        selected = new Set()
        addEvents();
    } catch (error) {
        // mailContainer.innerHTML = `<p>Error fetching mails: ${error.message}</p>`;
        console.log(error);
    }
    reload.style.transform = '';

}

fetchMails();
